<?php
    include 'connect.php';
    
    $email = $_POST['uemail'];
    $pass = $_POST['password'];
    
    $sql = "SELECT * FROM `admin` WHERE `email`='$email' AND `password`= md5('$pass') ";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    //print_r($row);
     if(is_array($row))
    {
        session_start();
        $_SESSION['admin'] = $row['id'];
        header("Location: users_list.php"); 
    }
    else
    {
        echo "Invalid Contact Number/Password <br/> <a href=".$_SERVER['HTTP_REFERER'].">click hear </a> to go back";
    }
?>