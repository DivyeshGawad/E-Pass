<?php

session_start();
unset($_SESSION["admin"]);
header("Location: https://www.jobsgetter.com/admin");
?>