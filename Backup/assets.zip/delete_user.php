<?php 
    session_start();
    if(isset($_SESSION['admin'])){
       
    }
    else{
        header("location:index.php");
    }
    if(isset($_GET['id'])){
       
    }
    else{
        header("location:user_list.php");
    }
    
    $id = $_GET['id'];
    include 'connect.php';
    $sql = "DELETE FROM `user` WHERE `id` = '$id'";
    if($dbresult = mysqli_query($conn, $sql)){
        header("Location: user_list.php");
    }
    else{
        echo "Error";
    }
?>