<?php 
    session_start();
    if(isset($_SESSION['admin'])){
       
    }
    else{
        header("location:index.php");
    }
    if(isset($_GET['id'])){
       
    }
    else{
        header("location:job_list.php");
    }
    
    $id = $_GET['id'];
    include 'connect.php';
    $sql = "DELETE FROM `jobpost` WHERE `id` = '$id'";
    if($dbresult = mysqli_query($conn, $sql)){
        header("Location: job_list.php");
    }
    else{
        echo "Error";
    }
?>